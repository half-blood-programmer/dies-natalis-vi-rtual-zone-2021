import '../../css/Modal.css';
import React from 'react';
import Map from '../../img/assets/map.jpg';

function JadwalDisnat(){
    return (
        <div className="maps">
            <img src={Map}></img>
        </div>
    );
  }
  
  export default JadwalDisnat;