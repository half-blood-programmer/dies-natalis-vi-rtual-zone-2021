import React from 'react';

function SideNav(){
  return <h2>Hai</h2>
}

export default SideNav;
